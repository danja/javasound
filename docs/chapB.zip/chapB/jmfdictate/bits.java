	///////////////////////////////////////
	Vector devices = null;

     devices = CaptureDeviceManager.getDeviceList(null);
        if ( (devices == null) || (devices.size() == 0) )
            System.out.println("No capture devices found in JMF registry!");
      else
            for (int i = 0; i < devices.size(); i++) {
                CaptureDeviceInfo cdi = (CaptureDeviceInfo)devices.elementAt(i);
                String name = cdi.getName();
            System.out.println("Name " +name);
          }
     
////////////////////////////////
// Component tc = proc.getControlPanelComponent();
// GainControl gc = proc.getGainControl();

// if(tc!=null)Dictate.content.add(tc);
// Component vc = proc.getVisualComponent();
// if(vc!=null)Dictate.content.add(vc);
// System.out.println(vc);
///////////////////////////////////////////
ContentDescriptor cd[] = proc.getSupportedContentDescriptors(); 
for(int i=0;i<cd.length;i++) System.out.println(cd[i]);
//////////////////////////////////////